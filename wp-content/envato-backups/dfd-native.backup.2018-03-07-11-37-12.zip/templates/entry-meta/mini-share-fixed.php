<?php
if (!defined('ABSPATH')) {
	exit;
}
?>
<div class="dfd-blog-share-fixed-wrap">
	<?php get_template_part('templates/entry-meta/mini','share-inner'); ?>
</div>