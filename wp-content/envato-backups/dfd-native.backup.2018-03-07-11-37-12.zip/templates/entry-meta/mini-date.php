<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<span class="entry-date updated"><i class="dfd-socicon-clock"></i><?php echo get_the_date(); ?></span>