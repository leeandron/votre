<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<span class="entry-date"><?php echo get_the_date('d. m. Y'); ?></span>