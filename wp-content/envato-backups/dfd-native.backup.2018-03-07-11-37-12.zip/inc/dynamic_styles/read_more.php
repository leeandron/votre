<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$output .= '.dfd-module-read-more-wrap.read-more-5 .icon-wrap:before,'
		. '.dfd-module-read-more-wrap.read-more-3 a:hover:hover .icon-wrap .line,'
		. '.dfd-module-read-more-wrap.read-more-6 a:hover .icon-wrap .dots {background: '.$vars['main_site_color'].';}';

$output .= '.dfd-module-read-more-wrap.read-more-5 a:hover .icon-wrap:before {background: '.$vars['main_color_darken_5'].';}';

$output .= '.dfd-module-read-more-wrap.read-more-8 .button i {color: '.$vars['main_site_color'].';}';