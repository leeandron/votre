<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$output .= '.dfd-heading-module-wrap .dfd-heading-delimiter{'
			   . 'border-bottom-color:'.$vars["main_site_color"].';'
		   . '}';