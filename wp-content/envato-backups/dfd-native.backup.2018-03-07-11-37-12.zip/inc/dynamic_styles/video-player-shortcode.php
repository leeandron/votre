<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$output .= '.dfd-videoplayer .decoration-icon {background: '.$vars['main_site_color'].';}';

$output .= '.dfd-videoplayer.style-2 .button-wrap:hover .decoration-icon {background: '.$vars['main_color_darken_5'].';}';