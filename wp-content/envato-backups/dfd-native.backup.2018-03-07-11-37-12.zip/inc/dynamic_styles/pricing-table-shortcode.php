<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$output .= '.dfd-pricing-block.style-03 .block-head,'
			.'.dfd-pricing-block.style-03 .block-bottom {background: '.$vars['main_site_color'].';}';

$output .= '.dfd-pricing-block.style-02 .icon-wrap {color: '.$vars['main_site_color'].';}';